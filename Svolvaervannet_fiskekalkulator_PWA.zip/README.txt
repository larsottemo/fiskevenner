Svolværvannet Fiskekalkulator – mobil/PWA

FILENE
- index.html
- manifest.json
- service-worker.js
- icon-192.png
- icon-512.png

ENKLeste måte å få den på mobilen:
1. Last opp hele innholdet i denne mappen til en HTTPS-nettside, for eksempel GitHub Pages.
2. Åpne nettsiden i Chrome på Android.
3. Velg «Installer app» / «Legg til på startskjermen».
4. Etter første innlasting vil kalkulatoren også fungere offline.

VIKTIG:
PWA/installasjon og service worker fungerer normalt ikke når index.html bare åpnes direkte
fra telefonens filsystem (file://). Den bør ligge på HTTPS, for eksempel GitHub Pages.

Modellen er en praktisk indikator basert på mønstre i registrerte data og er ikke en garanti
for fangst.
